			jQuery(document).ready(function() {
				openImmo.initialize();
			});